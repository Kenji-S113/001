@ECHO OFF
REM =======================================
REM Move batch file directory.
REM =======================================
pushd %~dp0

REM =======================================
REM preparation datetime setting.
REM =======================================
set DATETIME=%DATE%-%TIME%
set DATETIME=%DATETIME:/=%
set DATETIME=%DATETIME:\=%
set DATETIME=%DATETIME::=%
set DATETIME=%DATETIME:.=%
set DATETIME=%DATETIME:,=%
set DATETIME=%DATETIME: =%


REM =======================================
REM preparation make work directory.
REM =======================================
mkdir %COMPUTERNAME%_%DATETIME%
cd %COMPUTERNAME%_%DATETIME%


REM ======================================================================================
REM Getting users recent folder.
REM ======================================================================================
echo Phase 1/5

dir /b /ad %SystemDrive%\Users > .\temp_dir_users.txt
 
  For /f "delims=" %%a In (.\temp_dir_users.txt) Do ( 
   If Exist "%SystemDrive%\Users\%%a\AppData\Roaming\Microsoft\Office\Recent" (    
     mkdir .\%%a
     robocopy "%SystemDrive%\Users\%%a\AppData\Roaming\Microsoft\Office\Recent" .\%%a\Recent /mir >> .\run.log 2>&1
     REM ..\lib\sigcheck.exe -accepteula -nobanner -s -r -e -ct "%SystemDrive%\Users\%%a\AppData" > .\%%a\sig_output.txt 2>&1
   )
  )

REM If Exist "%SystemDrive%\Users\%username%\AppData\Roaming\Microsoft\Office\Recent" (
REM  mkdir .\%username%
REM  robocopy "%SystemDrive%\Users\%username%\AppData\Roaming\Microsoft\Office\Recent" .\%username%\Recent /mir >> .\run.log 2>&1
REM  ..\lib\sigcheck.exe -accepteula -nobanner -s -r -e -ct "%SystemDrive%\Users\%username%\AppData" > .\%username%\sig_output.txt 2>&1
REM )

REM ======================================================================================
REM Getting autorun info.
REM ======================================================================================
echo Phase 2/5

..\lib\autorunsc.exe -accepteula -nobanner -a * -ct -h -m -s * > output.txt 2>&1


REM ======================================================================================
REM Getting prosesses info.
REM ======================================================================================
echo Phase 3/5
REM wmic process list full /format:csv > processes.csv
powershell -NoProfile -exec bypass -Command "Get-Process | Select-Object * | Export-Csv -Path processes.csv -NoTypeInformation -Encoding UTF8"
powershell -NoProfile -exec bypass -Command "Get-CimInstance Win32_Process | Export-Csv -Path processes2.csv -NoTypeInformation -Encoding UTF8"


REM ======================================================================================
REM Getting network info.
REM ======================================================================================
echo Phase 4/5
netstat -nabo > netstat-nabo.txt
ipconfig -all > ipconfig-all.txt


REM ======================================================================================
REM Archive Datas.
REM ======================================================================================
echo Phase 4/5

cd ..

IF Exist ".\%COMPUTERNAME%_%DATETIME%" (
 .\lib\7z.exe a ".\%COMPUTERNAME%_%DATETIME%.zip" .\%COMPUTERNAME%_%DATETIME%\ > NUL 2>&1
)


REM ======================================================================================
REM Delete obsolete datas.
REM ======================================================================================

rmdir /S /Q .\%COMPUTERNAME%_%DATETIME%

echo;
echo ======================================================================================
echo Completed!
echo Please submit %COMPUTERNAME%_%DATETIME%.zip file to Security Personel.
echo ======================================================================================
echo;
REM PAUSE
