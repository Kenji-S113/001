Set WshShell = WScript.CreateObject("WScript.Shell")

Do
    WshShell.SendKeys "{F15}" ' F15キーを送信
    WScript.Sleep 300000        ' 1秒間待機（1000ミリ秒）
    CScript.echo "5min."
Loop